-------------------------------------------------------------
             Readme for Easy CHM
       Copyright (c) 2000-2013 Guohua Soft.
-------------------------------------------------------------

Create your first CHM help or CHM ebook in 10 seconds with Easy CHM.

Easy CHM is Free to try Software.
Easy CHM has trial version. This means that we have made the software available 
to you for free evaluation. You are entitled to evaluatethe software for 
up to 30 days without obligation to pay. After 30 days, if you decide to keep 
the software, you must register your copy with us..

REQUIREMENTS
------------
This program works under Windows 95/98/Me/NT/2000/XP/VISTA/WIN7 or higher.

INSTALLATION
------------
Run the setup file and follow the instructions.   

UNINSTALLATION
------------
Run the 'unins000.exe' and follow the instructions.    

LICENSE
------------
See the file 'License.txt'. 

CONTACTING THE AUTHOR
---------------------
If you have any problems, questions, suggestions please email to:
webmaster@etextwizard.com  

THE LATEST VERSION
------------------
You may download the latest version at:
   http://www.zipghost.com/download.html 
or 
   http://www.etextwizard.com/download.html   



Note:
  Copyright of these three files: hha.dll, hhc.exe and Itcc.dll belong to Microsoft.
you can Download them free from:
  http://msdn.microsoft.com/library/default.asp?url=/library/en-us/htmlhelp/html/vsconhh1start.asp 
